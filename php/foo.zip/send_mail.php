<?php
error_reporting(E_ALL|E_STRICT);
ini_set('display_errors', true);
header("Access-Control-Allow-Origin: *");

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;

/* Exception class. */
require 'PHPMailer/src/Exception.php';
/* The main PHPMailer class. */
require 'PHPMailer/src/PHPMailer.php';
/* SMTP class, needed if you want to use SMTP. */
require 'PHPMailer/src/SMTP.php';








$results = [];
// Connect to the database (create it if it doesn't exist)
$db = new SQLite3('data.db');


$content = trim(file_get_contents("php://input"));
$decoded = json_decode($content, true);

if ($decoded) {
    if (isset($decoded['action']) && $decoded['action'] === 'new_password') {
        if (isset($decoded['email'])) {
            $email = $decoded['email'];
            
            // Check if email already exists
            $emailExistsQuery = "SELECT * FROM users WHERE email = :email";
            $stmt = $db->prepare($emailExistsQuery);
            $stmt->bindValue(':email', $email, SQLITE3_TEXT);
            
            $result = $stmt->execute();
            
            if ($result && $result->fetchArray(SQLITE3_ASSOC)) {
                $results['success'] = false;
                $results['message'] = "Email already exists.";
				
				
				$newPassword = generateRandomPassword();  // Replace with your generated password
				// Hash the new password securely
				$hashedNewPassword = password_hash($newPassword, PASSWORD_DEFAULT);
				
				// Update user's password in the database
				$updateQuery = "UPDATE users SET password = :newPassword WHERE email = :email";
				$stmt = $db->prepare($updateQuery);
				$stmt->bindValue(':newPassword', $hashedNewPassword, SQLITE3_TEXT);
				$stmt->bindValue(':email', $email, SQLITE3_TEXT);
				$result = $stmt->execute();
				
				if ($result) {
				    echo "Password updated successfully.";
				    
					$mail = new PHPMailer(true);
					try {
					    //Server settings
					    $mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
					    $mail->isSMTP();                                            //Send using SMTP
					    $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
					    $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
					    $mail->Username   = 'smtp2128@gmail.com';                     //SMTP username
					    $mail->Password   = 'dvjvoxumnlmixtjg';                               //SMTP password
					    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
					    $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`
					
					    //Recipients
					    $mail->setFrom('from@example.com', 'Mailer');
					    $mail->addAddress($email, 'Joe User');     //Add a recipient
					    
					
					    //Attachments
					
					    //Content
					    $mail->isHTML(true);                                  //Set email format to HTML
					    $mail->Subject = 'New password ';
					    $mail->Body    = 'This is your new password <b>'.$newPassword.'</b>';
					    					
					    $mail->send();
					    echo 'Message has been sent';
					} catch (Exception $e) {
					    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
					}




				} else {
				    echo "Password update failed.";
				}

            } 
        } else {
            $results['success'] = false;
            $results['message'] = "Invalid data received.";
        }
    }
}


function generateRandomPassword($length = 10) {
    $characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    $password = '';
    
    for ($i = 0; $i < $length; $i++) {
        $randomIndex = rand(0, strlen($characters) - 1);
        $password .= $characters[$randomIndex];
    }
    
    return $password;
}
?>