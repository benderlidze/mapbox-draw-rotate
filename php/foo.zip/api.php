<?php
error_reporting(E_ALL|E_STRICT);
ini_set('display_errors', true);

header("Access-Control-Allow-Origin: *");

$results = [];
// Connect to the database (create it if it doesn't exist)
$db = new SQLite3('data.db');
$content = trim(file_get_contents("php://input"));
$decoded = json_decode($content, true);

if ($decoded) {
    if (isset($decoded['action'])) {
    	
		 if ($decoded['action'] === 'save-project') {
            // Save data action
            $polygon_id = $decoded['polygon_id'];
            $uid = isset($decoded['uid']) ? $decoded['uid'] : '';
            $data = isset($decoded['data']) ? $decoded['data'] : '';

            // Fetch user ID based on UID
            $userIdQuery = "SELECT id FROM users WHERE uid = :uid";
            $stmt = $db->prepare($userIdQuery);
            $stmt->bindValue(':uid', $uid, SQLITE3_TEXT);

            $result = $stmt->execute();
            $user = $result->fetchArray(SQLITE3_ASSOC);
			
            if ($user) {

                // Insert project information into the database
				$insertQuery = "UPDATE polygons SET  data = :data WHERE userid = :userid and id = :polygon_id";
				$stmt = $db->prepare($insertQuery);
				
				// Assuming you have the appropriate variables $name, $data, and $userid set elsewhere in your code
				$stmt->bindValue(':polygon_id', $polygon_id, SQLITE3_TEXT);
                $stmt->bindValue(':data', $data, SQLITE3_TEXT);
                $stmt->bindValue(':userid', $user['id'], SQLITE3_TEXT);

                $insertResult = $stmt->execute();

                if ($insertResult) {
                    $results['success'] = true;
                    $results['message'] = "Project saved successfully." . $insertQuery;
                } else {
                    $results['success'] = false;
                    $results['message'] = "Project saving failed.";
                }
            } else {
                $results['success'] = false;
                $results['message'] = "User not found.";
            }
        } elseif  ($decoded['action'] === 'save') {
            // Save data action
            $projectName = isset($decoded['projectName']) ? $decoded['projectName'] : '';
            $uid = isset($decoded['uid']) ? $decoded['uid'] : '';
            $data = isset($decoded['data']) ? $decoded['data'] : '';

            // Fetch user ID based on UID
            $userIdQuery = "SELECT id FROM users WHERE uid = :uid";
            $stmt = $db->prepare($userIdQuery);
            $stmt->bindValue(':uid', $uid, SQLITE3_TEXT);

            $result = $stmt->execute();
            $user = $result->fetchArray(SQLITE3_ASSOC);
			
            if ($user) {

                // Insert project information into the database
                $insertQuery = "INSERT INTO polygons (name, data, userid) VALUES (:name, :data, :userid)";
                $stmt = $db->prepare($insertQuery);
                $stmt->bindValue(':name', $projectName, SQLITE3_TEXT);
                $stmt->bindValue(':data', $data, SQLITE3_TEXT);
                $stmt->bindValue(':userid', $user['id'], SQLITE3_TEXT);

                $insertResult = $stmt->execute();

                if ($insertResult) {
                    $results['success'] = true;
                    $results['message'] = "Project saved successfully.";
                } else {
                    $results['success'] = false;
                    $results['message'] = "Project saving failed.";
                }
            } else {
                $results['success'] = false;
                $results['message'] = "User not found.";
            }
        } elseif ($decoded['action'] === 'load') {
            // Load data action
            $uid = isset($decoded['uid']) ? $decoded['uid'] : '';

            // Fetch project data based on user ID
            $loadQuery = "SELECT polygons.id AS polygon_id, polygons.name, polygons.data, users.id AS user_id, users.email
                          FROM polygons
                          LEFT JOIN users ON polygons.userid = users.id
                          WHERE users.uid = :uid";
		  
            $stmt = $db->prepare($loadQuery);
            $stmt->bindValue(':uid', $uid, SQLITE3_TEXT);

            $result = $stmt->execute();

            if ($result) {
                $data = [];

                while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
                    $data[] = $row;
                }

                $results['success'] = true;
                $results['data'] = $data;
            } else {
                $results['success'] = false;
                $results['message'] = "Failed to fetch data.";
            }
        } else {
            $results['success'] = false;
            $results['message'] = "Invalid action.";
        }
    } else {
        $results['success'] = false;
        $results['message'] = "Invalid data received.";
    }
} else {
    $results['success'] = false;
    $results['message'] = "Invalid data received.";
}

// Return JSON response
header('Content-Type: application/json');
echo json_encode($results);
?>