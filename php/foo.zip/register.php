<?php
error_reporting(E_ALL|E_STRICT);
ini_set('display_errors', true);

header("Access-Control-Allow-Origin: *");


$results = [];
// Connect to the database (create it if it doesn't exist)
$db = new SQLite3('data.db');

// Create a table if it doesn't exist
$query = "CREATE TABLE IF NOT EXISTS polygons (id INTEGER PRIMARY KEY, name VARCHAR(255), data TEXT, userid VARCHAR(255))";
$db->exec($query);
$query = "CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, uid VARCHAR(255), email VARCHAR(255), password VARCHAR(255))";
$db->exec($query);

$content = trim(file_get_contents("php://input"));
$decoded = json_decode($content, true);

if ($decoded) {
    if (isset($decoded['action']) && $decoded['action'] === 'register') {
        if (isset($decoded['email']) && isset($decoded['password'])) {
            $email = $decoded['email'];
            $password = $decoded['password'];
            
            // Check if email already exists
            $emailExistsQuery = "SELECT * FROM users WHERE email = :email";
            $stmt = $db->prepare($emailExistsQuery);
            $stmt->bindValue(':email', $email, SQLITE3_TEXT);
            
            $result = $stmt->execute();
            
            if ($result && $result->fetchArray(SQLITE3_ASSOC)) {
                $results['success'] = false;
                $results['message'] = "Email already exists.";
            } else {
                // Hash the password securely
                $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
				$uid = md5($email.time());

                // Insert user information into the database
                $insertQuery = "INSERT INTO users (email, uid, password) VALUES (:email, :uid,  :password)";
                $stmt = $db->prepare($insertQuery);
                $stmt->bindValue(':email', $email, SQLITE3_TEXT);
                $stmt->bindValue(':password', $hashedPassword, SQLITE3_TEXT);
				$stmt->bindValue(':uid', $uid, SQLITE3_TEXT);
                
                $insertResult = $stmt->execute();

                if ($insertResult) {
                    $results['success'] = true;
                    $results['message'] = "User registered successfully.";
					$results['uid'] = $uid;
					$results['email'] = $email;
                } else {
                    $results['success'] = false;
                    $results['message'] = "User registration failed.";
                }
            }
        } else {
            $results['success'] = false;
            $results['message'] = "Invalid data received.";
        }
    } elseif (isset($decoded['action']) && $decoded['action'] === 'login') {
        if (isset($decoded['email']) && isset($decoded['password'])) {
            $email = $decoded['email'];
            $password = $decoded['password'];
            
            // Retrieve user information based on email
            $getUserQuery = "SELECT * FROM users WHERE email = :email";
            $stmt = $db->prepare($getUserQuery);
            $stmt->bindValue(':email', $email, SQLITE3_TEXT);
            
            $result = $stmt->execute();
            
            $user = $result->fetchArray(SQLITE3_ASSOC);
            
            if ($user && password_verify($password, $user['password'])) {
                $results['success'] = true;
                $results['message'] = "Login successful.";
                $results['uid'] = $user['uid'];
				$results['email'] = $user['email'];
            } else {
                $results['success'] = false;
                $results['message'] = "Login failed.";
            }
        } else {
            $results['success'] = false;
            $results['message'] = "Invalid data received.";
        }
    } else {
        $results['success'] = false;
        $results['message'] = "Invalid action.";
    }
} else {
    $results['success'] = false;
    $results['message'] = "Invalid data received.";
}

// Return JSON response
header('Content-Type: application/json');
echo json_encode($results);
?>

