<?php 
$con = mysqli_connect('localhost', 'sergone_mapbox', 'benderlio123', 'sergone_draw_tool');
?>
