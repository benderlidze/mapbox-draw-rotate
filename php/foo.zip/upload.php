<?
error_reporting(E_ALL|E_STRICT);
ini_set('display_errors', true);
header("Access-Control-Allow-Origin: *");

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['image']['tmp_name'])) {
    $targetDir = 'images/';
    $targetFile = $targetDir . basename($_FILES['image']['name']);
    
    if (move_uploaded_file($_FILES['image']['tmp_name'], $targetFile)) {
        $imgInfo = getimagesize($targetFile);
        
        if ($imgInfo) {
            list($originalWidth, $originalHeight, $imageType) = $imgInfo;
            
            // Create image resource based on image type
            switch ($imageType) {
                case IMAGETYPE_JPEG:
                    $image = imagecreatefromjpeg($targetFile);
                    break;
                case IMAGETYPE_PNG:
                    $image = imagecreatefrompng($targetFile);
                    break;
                // Add more cases for other image types if needed
                default:
                    echo json_encode(['success' => false, 'message' => 'Unsupported image type.']);
                    exit;
            }
            
    $newWidth = 200;
    $newHeight = 200;
    
    // Create a blank square canvas with transparent background for PNG
    $canvas = imagecreatetruecolor($newWidth, $newHeight);
    imagealphablending($canvas, false);
    imagesavealpha($canvas, true);
    
    // Fill the canvas with a transparent color
    $transparentColor = imagecolorallocatealpha($canvas, 0, 0, 0, 127);
    imagefill($canvas, 0, 0, $transparentColor);
    
    // Resize and fit the image within the canvas
    imagecopyresampled($canvas, $image, 0, 0, 0, 0, $newWidth, $newHeight, $originalWidth, $originalHeight);
    
    $fileExtension = strtolower(image_type_to_extension($imageType));
    // Generate a random image name
    $resizedFilename = generateRandomImageName($fileExtension);
    
    // Save the resized image with transparency
    imagepng($canvas, $targetDir . $resizedFilename);
	
            
            // Get the full path to the resized image
            //$fullImagePath = realpath($targetDir . $resizedFilename);
			
			
			$serverProtocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://';
			
			$currentScriptPath = dirname($_SERVER['SCRIPT_NAME']);
			$baseURL = $serverProtocol . $_SERVER['HTTP_HOST'] . $currentScriptPath . '/';
			$fullImageURL = $baseURL . $targetDir . $resizedFilename;

            
            // Clean up resources
            imagedestroy($image);
            imagedestroy($canvas);
            
            echo json_encode(['success' => true, 'file' => $resizedFilename, 'fullURL' => $fullImageURL, 'message' => 'Image uploaded and resized successfully.']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Invalid image format.']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to upload image.']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request.']);
}

// Generate a random image name
function generateRandomImageName($extension) {
    $timestamp = time();
    $uniqueId = uniqid();
    $randomNumber = mt_rand(1000, 9999); // You can adjust the range as needed
    $randomImageName = "{$timestamp}_{$uniqueId}_{$randomNumber}{$extension}";
    return $randomImageName;
}

?>