<?
error_reporting(E_ALL|E_STRICT);
ini_set('display_errors', true);

header("Access-Control-Allow-Origin: *");

$results = [];
// Connect to the database (create it if it doesn't exist)
$db = new SQLite3('data.db');


// Perform an INNER JOIN between polygons and users
$query = "SELECT *
          FROM users
          ";

$result = $db->query($query);
if ($result) {
    $data = [];
    while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
		echo '<div style="border:1px solid gray;padding:10px;margin:5px">'.$row['id'].' | '.$row['email'].' | '.$row['uid'].'</div>';
    }
} 

// Perform an INNER JOIN between polygons and users
$query = "SELECT polygons.id AS polygon_id, 
			polygons.data,
			polygons.name as name,  
			users.id AS user_id,
			users.email
          FROM polygons
          LEFT JOIN users ON polygons.userid = users.id";

$result = $db->query($query);

if ($result) {
    $data = [];

    while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
        
		echo '<div style="border:1px solid gray;padding:10px;margin:5px">'.$row['email'].' <b>'.$row['name'].'</b> '.$row['data'].'</div>';
		
    }

} 

?>